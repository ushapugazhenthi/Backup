# v0.0.1 - Update to Angular 2 Beta (2016-01-07)

* Upgraded to work with Angular 2 Beta 0
* Removed Fetch API in favor of Angular 2 Http
* Included [angular2-jwt](https://github.com/auth0/angular2-jwt) for authenticated API calls

