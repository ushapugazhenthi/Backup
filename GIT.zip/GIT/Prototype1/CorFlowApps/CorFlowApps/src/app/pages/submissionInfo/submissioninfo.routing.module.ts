import { Routes, RouterModule }  from '@angular/router';
import {SubmissionInfoComponent} from './submissioninfo.component';
import {BasicInfoSectionDetailsComponent} from './basicinfosectiondetails.component';
import {ClientInfoComponent} from './clientinfo.component';
const routes: Routes = [
 
  {
    path: '',
    component: SubmissionInfoComponent
  },
  
 {
     path:'basicinformations',
     component: BasicInfoSectionDetailsComponent
 },
 {
    path:'clientinformations',
     component: ClientInfoComponent
  },
];

export const routing = RouterModule.forChild(routes);