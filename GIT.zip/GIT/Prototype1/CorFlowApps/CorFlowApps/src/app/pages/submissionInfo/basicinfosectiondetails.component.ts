import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
    selector :'basic-information',
    templateUrl:'./basicinfo.html'
      
})
export class BasicInfoSectionDetailsComponent{
    
    constructor(private router:Router){}
    
    goToClientSection(){
        console.log("Hello USha P");
        
        //this.router.navigateByUrl('/pages/submissionInfo');
        this.router.navigateByUrl('/pages/submissionInfo/clientinformations');
    }
}