import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {SubmissionInfoComponent} from './submissioninfo.component';
import {BasicInfoSectionDetailsComponent} from './basicinfosectiondetails.component';
import {ClientInfoComponent} from './clientinfo.component';
import { routing } from './submissioninfo.routing.module';
import { MaterialModule } from '@angular/material';
import { NgaModule } from '../../theme/nga.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    routing,
    MaterialModule.forRoot()
  ],
  declarations: [
    SubmissionInfoComponent,
    BasicInfoSectionDetailsComponent,
    ClientInfoComponent
  ]
})
export class SubmissionInfoModule {}