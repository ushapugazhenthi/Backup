"use strict";
exports.__esModule = true;
var router_1 = require("@angular/router");
var basicinfo_component_1 = require("./basicinfo.component");
var submission_component_1 = require("./submission.component");
var routes = [
    {
        path: '',
        component: basicinfo_component_1.BasicInfoComponent
    },
    {
        path: 'submissionsection',
        component: submission_component_1.SubmissionComponent
    }
    /**
     *
     * {
        path: '',
        component :BasicInfoComponent
    },
    {
        path: 'clientinfo',
        component :ClientInfoComponent
    }
    
    
    path: '',
component: Tables,
children: [
{ path: 'basictables', component: BasicTables }
]
**/
];
exports.routing = router_1.RouterModule.forChild(routes);
//export class AppRouterModule{}
//export const allroutingComponents =[BasicInfoSectionComponent,ClientInfoComponent]; 
