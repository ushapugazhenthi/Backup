import {Component} from '@angular/core';
//import{RouterModule, Routes} from '@angular/router';
import {Router} from '@angular/router';


@Component({
   selector: 'test-summary',
  //template: `<p>Hello Submission
  //<custom-tag>Place the Form here</custom-tag>`
  //template: `<h1>This Is Basic Info Component</h1>`
  templateUrl:'./dashboard/basicinfo.html'
  

})
export class BasicInfoComponent{


  public applyclass=true;
  
  
   constructor(private router:Router){}
   
   
  getSUBMISSIONSType(): String {

        return 'SUBMISSIONS';
}

showtheForm(){
  
 // document.getElements
}


redirectToSubmission(){
  console.log("Greetings Usha");
  //this.router.navigateByUrl('/pages/dashboard');
  //this.router.navigateByUrl('/submissionsection');
//  this.router.navigateByUrl('/pages/mails1');--/pages/dashboard
  this.router.navigateByUrl('/pages/submissionInfo');
}
}