import {Component} from '@angular/core';

@Component({
  selector: 'claim-summary',
  template: `<claim-summary-dashboard></claim-summary-dashboard>`
})
export class ClaimSummaryComponent {
  constructor() {}
}