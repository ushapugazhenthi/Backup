import {NgModule} from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import {BrowserModule} from '@angular/platform-browser';
import{RouterModule} from '@angular/router';
import {BasicInfoComponent} from './basicinfo.component';
import{BasicInfoSectionComponent} from './basicInfoSecComponent.component';
import{ClientInfoComponent} from './clientinfo.component';
import { MaterialModule } from '@angular/material';
import { NgaModule } from '../../theme/nga.module';
import {routing} from './basicinfo.routing';



//import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// /
//if any new componeb=nt is added it can be imoported here

@NgModule({
     imports :[
       
        //BrowserModule,
        FormsModule,
        //AppRouterModule
        CommonModule,
        NgaModule,
         routing,
        MaterialModule.forRoot(),
        
        
       
    ],
    declarations :[
            BasicInfoComponent,
            BasicInfoSectionComponent,
             ClientInfoComponent,
             
            ],
            
        //    bootstrap :[BasicInfoComponent]
})

export class BasicInformationModule {
    //debugger;
    
}








