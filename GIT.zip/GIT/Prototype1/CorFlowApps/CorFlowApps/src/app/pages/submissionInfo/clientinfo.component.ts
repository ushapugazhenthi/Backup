import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
    selector :'client-information',
    templateUrl:'./clientinfo.html'
   
})

export class ClientInfoComponent{
   
    gotoBasicInfo(){
        console.log("Hello USha P");
        
        this.router.navigateByUrl('/pages/submissionInfo/basicinformations');
        
    }
    
    constructor(private router:Router){}
    
    
   
    
    
}