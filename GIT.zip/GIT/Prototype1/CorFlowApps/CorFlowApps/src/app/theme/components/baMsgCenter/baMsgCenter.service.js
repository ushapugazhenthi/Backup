"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
exports.__esModule = true;
var core_1 = require("@angular/core");
var BaMsgCenterService = (function () {
    function BaMsgCenterService() {
        this._notifications = [
            {
                name: 'S3KSZM',
                text: 'First Notification.',
                time: '1 min ago'
            },
            {
                name: 'S3KSZM',
                text: 'Second Notification.',
                time: '2 hrs ago'
            },
            {
                name: 'S3KSZM',
                text: '3rd Notification.',
                time: '5 hrs ago'
            }
        ];
        this._messages = [
            {
                name: 'S3KSZM',
                text: 'Test Msg 1...',
                time: '1 min ago'
            },
            {
                name: 'S3KSZM',
                text: 'Test Message 2.',
                time: '2 hrs ago'
            },
            {
                name: 'S3KSZM',
                text: 'Test Message 3..',
                time: '10 hrs ago'
            },
            {
                name: 'S3KSZM',
                text: 'Test Message 4...',
                time: '1 day ago'
            }
        ];
    }
    BaMsgCenterService.prototype.getMessages = function () {
        return this._messages;
    };
    BaMsgCenterService.prototype.getNotifications = function () {
        return this._notifications;
    };
    return BaMsgCenterService;
}());
BaMsgCenterService = __decorate([
    core_1.Injectable()
], BaMsgCenterService);
exports.BaMsgCenterService = BaMsgCenterService;
