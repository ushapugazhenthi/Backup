export * from './highchart.component'
