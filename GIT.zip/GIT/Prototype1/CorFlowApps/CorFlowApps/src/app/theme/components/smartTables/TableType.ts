export enum TableType{
    CLAIM,
    ACTIVITY,
    COLLABORATION,
    MAILS
  

}


