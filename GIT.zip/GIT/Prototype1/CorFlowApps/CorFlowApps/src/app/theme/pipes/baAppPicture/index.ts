export * from './baAppPicture.pipe';
