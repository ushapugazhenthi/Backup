import {Pipe, PipeTransform} from '@angular/core';
import {layoutPaths} from '../../../theme';

@Pipe({name: 'baProfilePicture'})
export class BaProfilePicturePipe implements PipeTransform {

  transform(input:string, ext = 'png'):string {
    console.log(layoutPaths.images.SRPath  + input +layoutPaths.images.JPEGPath);
    return layoutPaths.images.SRPath  + input +layoutPaths.images.JPEGPath;
  }
}
