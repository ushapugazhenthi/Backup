import {Component, ElementRef, HostListener,Input, Output, EventEmitter} from '@angular/core';
import {GlobalState} from '../../../global.state';
import {layoutSizes} from '../../../theme';




@Component({
  selector: 'highchart',
  templateUrl: './highchart.html'
})
export class Highchart {
    @Input() chartOptions:Object;
    
}