import {Component} from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'sidenav-overview-example',
  templateUrl: './sidenav-overview-example.html',
  styleUrls: ['./sidenav-overview-example.css'],
})
export class SidenavOverviewExample {

  spaceScreens: Array<any>;


  constructor(private http:Http) {
    
    this.http.get('./data.json')
      .map(response => response.json().screenshots)
      .subscribe(res => this.spaceScreens = res);

  }
}


/**  Copyright 2017 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */