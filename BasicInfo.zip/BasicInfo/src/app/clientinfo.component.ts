import { Component } from '@angular/core';


@Component({
    selector :'cleint-information',
    templateUrl:'./clientinfo.html'
   
})

export class ClientInfoComponent{}