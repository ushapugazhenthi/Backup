import { Component } from '@angular/core';


@Component({
    selector :'basic-information',
    templateUrl:'./basicinfo.html'
      
})
export class BasicInfoComponent{
    
    
}