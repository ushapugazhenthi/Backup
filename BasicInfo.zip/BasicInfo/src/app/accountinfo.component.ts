import { Component } from '@angular/core';


@Component({
    selector :'basic-information',
   templateUrl:'./account.html'
    
})

export class AccountInformationComponent{}