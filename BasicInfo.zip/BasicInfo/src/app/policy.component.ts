import { Component } from '@angular/core';


@Component({
    selector :'policy-information',
    templateUrl :'./policy.html'
    
    
})

export class PolicyComponent
{}