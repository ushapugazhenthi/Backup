import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';

import {RouterModule} from '@angular/router';
import {BasicInfoComponent}  from './basicinfo.component';
import {ClientInfoComponent} from './clientinfo.component';
import {PolicyComponent} from './policy.component';
import {AccountInformationComponent} from './accountinfo.component';
//import {StructureComponent} from './structure.component';
//import {HistoricalInfoComponent} from './HistoricalInfo.component';



@NgModule({
  imports: [ BrowserModule ,
             CommonModule,FormsModule,
              RouterModule.forRoot(
                [
                  {
                    path:'basicinformations',
                    component: BasicInfoComponent
                  },
                   {
                    path:'clientinformations',
                    component: ClientInfoComponent
                  },
                   {
                    path:'policyinfo',
                    component: PolicyComponent
                  },

             {
                    path:'accountinfo',
                    component: AccountInformationComponent
                  }
                  
                ])
             
  ],
  declarations: [ AppComponent,BasicInfoComponent,ClientInfoComponent,PolicyComponent,
  AccountInformationComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
