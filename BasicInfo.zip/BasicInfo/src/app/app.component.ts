import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
            <h1> Submission Details</h1>
            <nav>
            <a routerLink="/basicinformations" routerLinkActive="active">
            Basic Information
            </a>
            
            
            <a routerLink="/clientinformations" routerLinkActive="active">
            Client Information
            </a>
            
            <a routerLink="/policyinfo" routerLinkActive="active">
            Policy information
            </a>
            
            
            <a routerLink="/accountinfo" routerLinkActive="active">
            account information
            </a>
            </nav>
            <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'Minimal NgModule';
}
