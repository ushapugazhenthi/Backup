"use strict";
exports.__esModule = true;
var TableType;
(function (TableType) {
    TableType[TableType["CLAIM"] = 0] = "CLAIM";
    TableType[TableType["ACTIVITY"] = 1] = "ACTIVITY";
    TableType[TableType["COLLABORATION"] = 2] = "COLLABORATION";
    TableType[TableType["MAILS"] = 3] = "MAILS";
})(TableType = exports.TableType || (exports.TableType = {}));
