"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
exports.__esModule = true;
__export(require("./baMenuItem.component"));
exports.PAGES_MENU = [
    {
        path: 'pages',
        children: [
            {
                path: 'dashboard',
                data: {
                    menu: {
                        title: 'Dashboard',
                        icon: 'ion-android-desktop',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'mails',
                data: {
                    menu: {
                        title: 'Mails',
                        icon: 'ion-email',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'description',
                data: {
                    menu: {
                        title: 'Submissions',
                        icon: 'ion-document-text',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'deals',
                data: {
                    menu: {
                        title: 'Deals',
                        icon: 'ion-compose',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            },
            {
                path: 'tasks',
                data: {
                    menu: {
                        title: 'Tasks',
                        icon: 'ion-clipboard',
                        selected: false,
                        expanded: false,
                        order: 0
                    }
                }
            }
        ]
    }
];
