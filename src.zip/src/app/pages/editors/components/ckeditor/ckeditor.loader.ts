window['CKEDITOR_BASEPATH'] = '//cdn.ckeditor.com/4.6.0/full/';
