"use strict";
exports.__esModule = true;
var router_1 = require("@angular/router");
var pages_component_1 = require("./pages.component");
// noinspection TypeScriptValidateTypes
// export function loadChildren(path) { return System.import(path); };
exports.routes = [
    {
        path: 'pages',
        component: pages_component_1.Pages,
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', loadChildren: 'app/pages/dashboard/dashboard.module#DashboardModule' },
            { path: 'mails1', loadChildren: 'app/pages/claimSummary/claimSummary.module#ClaimSummaryModule' },
            //{path:'submissions',loadChildren:'app/pages/claimSummary/claimSummary.module#ClaimSummaryModule'}
            { path: 'submissions', loadChildren: 'app/pages/basicinfo/basicinfo.module#BasicInformationModule' }
            //  { path: 'mails1',  loadChildren: 'app\pages\basicinfo/basicinfo.module#BasicInfoModule' }
        ]
    }
];
exports.routing = router_1.RouterModule.forChild(exports.routes);
