import { Routes, RouterModule }  from '@angular/router';
import { Pages } from './pages.component';
import { ModuleWithProviders } from '@angular/core';
// noinspection TypeScriptValidateTypes

// export function loadChildren(path) { return System.import(path); };

export const routes: Routes = [
  
  {
    path: 'pages',
    component: Pages,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadChildren: 'app/pages/dashboard/dashboard.module#DashboardModule' },
     
      { path: 'mails1',  loadChildren: 'app/pages/claimSummary/claimSummary.module#ClaimSummaryModule' },
      {path:'submissions',loadChildren:'app/pages/basicinfo/basicinfo.module#BasicInformationModule'},
     // {path:'new1',loadChildren:'app/pages/claimSummary/claimSummary.module#ClaimSummaryModule'},
      //{path:'submissions',loadChildren:'app/pages/basicinformation/claimSummary/claimSummary.module#ClaimSummaryModule'}
  //pages\basicinformation\claimSummary
    
    {path:'submissionInfo',loadChildren:'app/pages/submissionInfo/submissioninfo.module#SubmissionInfoModule'}
    
    ]
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
