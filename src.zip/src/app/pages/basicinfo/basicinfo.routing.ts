import {NgModule} from '@angular/core';
import{RouterModule, Routes} from '@angular/router';
import{BasicInfoComponent}  from './basicinfo.component' ;
import{BasicInfoSectionComponent} from './basicInfoSecComponent.component';
import{ClientInfoComponent} from './clientinfo.component';

const routes :Routes =[
              
            
            
           {
        path: '',
        component: BasicInfoComponent,
        
     }
            
            /**
             * 
             * {
                path: '',
                component :BasicInfoComponent
            },
            {
                path: 'clientinfo',
                component :ClientInfoComponent
            }
            
            
            path: '',
    component: Tables,
    children: [
      { path: 'basictables', component: BasicTables }
    ]
    **/
];

export const routing = RouterModule.forChild(routes);

//export class AppRouterModule{}
//export const allroutingComponents =[BasicInfoSectionComponent,ClientInfoComponent];