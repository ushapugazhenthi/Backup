"use strict";
exports.__esModule = true;
var router_1 = require("@angular/router");
var basicinfo_component_1 = require("./basicinfo.component");
//import{ClientInfoComponent} from './clientinfo.component';
var routes = [
    {
        path: 'submissions',
        component: basicinfo_component_1.BasicInfoComponent
    },
];
exports.routing = router_1.RouterModule.forChild(routes);
var AppRouterModule = (function () {
    function AppRouterModule() {
    }
    return AppRouterModule;
}());
exports.AppRouterModule = AppRouterModule;
//export const allroutingComponents =[BasicInfoSectionComponent,ClientInfoComponent]; 
