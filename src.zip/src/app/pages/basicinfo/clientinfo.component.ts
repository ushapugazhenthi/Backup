import {Component} from '@angular/core';

@Component({
  selector: "[routerLink ='/clientinfo']",
  //templateUrl: './clientinfo.html'
  template:'<h3>Client Info Section</h3>'
})
export class ClientInfoComponent{
    
        onSubmit(value: any){
        console.log(value);
    }
    
}