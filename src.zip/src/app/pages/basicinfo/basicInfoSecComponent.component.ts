import {Component} from '@angular/core';
declare var require: any;
var Highcharts = require('highcharts/highcharts');

@Component({
  selector: 'my-custom',
  template:'<h3>Basic Info Section</h3>'
})
export class BasicInfoSectionComponent { 
}