import {Component} from '@angular/core';
//import{RouterModule, Routes} from '@angular/router';



@Component({
   selector: 'test-summary',
  //template: `<p>Hello Submission
  //<custom-tag>Place the Form here</custom-tag>`
  //template: `<h1>This Is Basic Info Component</h1>`
  templateUrl:'./dashboard/basicinfo.html'
  

})
export class BasicInfoComponent{
   constructor() {}
  //lineOfBusiness: string ="LOB";
  public applyclass=true;
  
  getSUBMISSIONSType(): String {

        return 'SUBMISSIONS';
}

showtheForm(){
  console.log("Greetings");
  document.getElements
}
}