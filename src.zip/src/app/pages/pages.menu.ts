export const PAGES_MENU = [
    {
        path: 'pages',
        // parent route
        children: [
            {
                path: 'dashboard',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Dashboard',
                        icon: 'ion-android-desktop',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },
            {
                path: 'mails1',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Mails',
                        icon: 'ion-email',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },

            {
                // parent route
                path: 'submissions',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Submissions',
                        icon: 'ion-document-text',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },

                // children routes
        
            },
            {
                // parent route
                path: 'deals',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Deals',
                        icon: 'ion-compose',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },

                // children routes
                children: [
                    {
                        path: 'new1',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'New',
                                icon: 'ion-compose',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        }
                    },
                    {
                        path: 'existing',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'Existing',
                                icon: 'ion-compose',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        }
                    }
                ]
            },
            {
                path: 'tasks',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Tasks',
                        icon: 'ion-clipboard',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },
            
            //submissionInfo
            /*
            {
                path: 'submissionInfo',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'sub-details',
                        hide:true,
                        
                       
                    }
                },
            },
            
            */
            
            
            
            
        ]

    }

];
