import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {AccountInfoFormData} from './accountinfo.service';
import {AccountInfoServiceComponent} from './accountinfo.service';

 
@Component({
    selector :'basic-information',
   templateUrl:'./account.html'
    
})

export class AccountInformationComponent{
    headquarterCountry:string;
    geoScope:string;
    
     accountinfo:AccountInfoFormData ;
    ngOnInit() : void
    {
        /*
      this.productconfiguration=this.basicService.getTheData();
        console.log("The Value from the Service is:"+ 
         this.productconfiguration);
         */
        
        this.accountinfo=this.accountService.getTheAccountData();
        this.headquarterCountry=this.accountinfo.hqc;
        this. geoScope=this.accountinfo.gs;
       
        console.log("The Form Model value is: "+ this.accountinfo.hqc +", "
        +this.accountinfo.gs );
    }
  
    
    
    constructor(private router:Router, 
    private accountService:AccountInfoServiceComponent){}
    
    
    
    
    goToPolicy(){
       this.router.navigateByUrl('/pages/submissionInfo/policyinfo');
    }
    
    goToStructure(){
         this.router.navigateByUrl('/pages/submissionInfo/structure');
    }
    
    
    onSubmit(value:any){
       this.accountService.accountFormData(value.headquarterCountry,
       value.geoScope
       );
        
      
      this.headquarterCountry=value.headquarterCountry;
      this.geoScope=value.geoScope;
      console.log("The Form value is:"+this.headquarterCountry+","+  this.geoScope
     );
     
    }
    
    
    
}