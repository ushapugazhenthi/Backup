import { Routes, RouterModule }  from '@angular/router';
import {SubmissionInfoComponent} from './submissioninfo.component';
import {BasicInfoSectionDetailsComponent} from './basicinfosectiondetails.component';
import {ClientInfoComponent} from './clientinfo.component';
import {PolicyComponent} from './policy.component';
import {AccountInformationComponent}  from './accountinfo.component';
import {StructureComponent} from './structure.component';
import {HistoricalComponent} from './historical.component';

const routes: Routes = [
 
  {
    path: '',
    component: SubmissionInfoComponent
  },
  
 {
     path:'basicinformations',
     component: BasicInfoSectionDetailsComponent
 },
 {
    path:'clientinformations',
     component: ClientInfoComponent
  },
  {
      path:'policyinfo',
      component: PolicyComponent
    },
  {
      path:'accountinfo',
      component: AccountInformationComponent
    },
      
    {
      path:'structure',
      component:StructureComponent
    },
    
    {
      path:'historical',
      component:HistoricalComponent
    },
    
  
];

export const routing = RouterModule.forChild(routes);