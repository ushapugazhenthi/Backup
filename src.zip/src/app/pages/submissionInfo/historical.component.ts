import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
    selector :'history-information',
    templateUrl :'./historical.html'
    
    
})

export class HistoricalComponent
{
   
    goToStructureInfo()
    {
        this.router.navigateByUrl('/pages/submissionInfo/structure'); 
    }
    constructor(private router:Router){}
}