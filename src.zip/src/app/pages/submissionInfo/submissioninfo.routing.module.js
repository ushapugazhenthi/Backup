"use strict";
exports.__esModule = true;
var router_1 = require("@angular/router");
var module_1 = require();
'./submissioninfo.component';
var routes = [
    {
        path: '',
        component: module_1.SubmissionInfoComponent
    },
];
exports.routing = router_1.RouterModule.forChild(routes);
