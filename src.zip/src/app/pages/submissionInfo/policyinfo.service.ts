import { Injectable } from '@angular/core';

@Injectable()
export class PolicyInfoServiceComponent{
   treaty:string;
   marketPos:string;
    
    policyForm:PolicyInfoFormData;
    
    policyFormData(treatyType:string, marketPosition:string){
       this.treaty=treatyType;
       this.marketPos =marketPosition;
       console.log("the Policy info Data received in the service is: "+this.treaty +", "+ this.marketPos )
    }
    
    getThePolicyData(){
        this.policyForm ={
           treatyType: this.treaty,
           marketPosition:this.marketPos
          
        }
        
        console.log("The Value returned to  the  Policycomponent is:"+ this.policyForm.treatyType+","
        + this.policyForm.treatyType);
       
         
       
       // return this.pc;
       return this.policyForm;
    }
    
}

export class PolicyInfoFormData {
 treatyType: string;
  marketPosition: string;
  
}