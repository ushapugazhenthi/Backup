import { Component } from '@angular/core';
import {Router} from '@angular/router';
import {StructureInfoServiceComponent} from './structure.service';
import {StructureInfoFormData} from './structure.service';
@Component({
    selector :'structure-information',
    templateUrl :'./structure.html'
    
    
})

export class StructureComponent
{
    currency:string;
    brokertargetprices:string;
    
     structureInfo:StructureInfoFormData;
    
     ngOnInit() : void
    {
       
        
        this.structureInfo=this.structureService.getTheStructurData();
        this.currency=this.structureInfo.currency;
        this.brokertargetprices=this.structureInfo.btp;
        
        console.log("The Policy Form Model value from the  service is: "
       + this.structureInfo.currency+
        "," +this.structureInfo.btp);
    }
   
   onSubmit(formPolicyInfoValue){
        
        this.currency =formPolicyInfoValue.currency;
      this.brokertargetprices=formPolicyInfoValue.brokertargetprices;
       console.log("The Structure Form value is:"+this.currency+","+ 
        this.brokertargetprices);
      this.structureService.structureFormData(this.currency,this.brokertargetprices)
        
    }
    constructor(private router:Router,
    private structureService:StructureInfoServiceComponent){} 
    
    
    
    
    goToHistoricalInfo(){
        this.router.navigateByUrl('/pages/submissionInfo/historical');  
    }
    
    goToAccountInfo(){
      this.router.navigateByUrl('/pages/submissionInfo/accountinfo');  
    }
    
}