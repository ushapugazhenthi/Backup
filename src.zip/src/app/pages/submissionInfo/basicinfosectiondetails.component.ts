import { Component } from '@angular/core';
import {Router} from '@angular/router';
import { FormGroup }from '@angular/forms';
import {BasicInfoSectionService} from './basicinfosection.service'
import {BasicInfoFormData} from './basicinfosection.service';

@Component({
    selector :'basic-information',
    templateUrl:'./basicinfo.html',
    
      
})
export class BasicInfoSectionDetailsComponent implements OnInit {
    
    productconfiguration:string='';
    businessArea:string = '';
    workType:string='';
   basicinfo:BasicInfoFormData ;
    ngOnInit() : void
    {
        /*
      this.productconfiguration=this.basicService.getTheData();
        console.log("The Value from the Service is:"+ 
         this.productconfiguration);
         */
        
        this.basicinfo=this.basicService.getTheData();
        this.productconfiguration=this.basicinfo.proConfig;
        this. businessArea=this.basicinfo.businessArea;
        this.workType=this.basicinfo.workType;
        console.log("The Form Model value is: "+ this.basicinfo.proConfig);
    }
  
    
    
    constructor(private router:Router, 
    private basicService:BasicInfoSectionService){}
    
    goToClientSection(){
        console.log("Hello USha P");
        
        //this.router.navigateByUrl('/pages/submissionInfo');
        this.router.navigateByUrl('/pages/submissionInfo/clientinformations');
    }
    
    onSubmit(value:any){
       this.basicService.basicFormData(value.productconf,value.busiArea,
       value.workType);
        
      this.businessArea =value.busiArea;
      this.productconfiguration=value.productconf;
      this.workType=value.workType;
      console.log("The Form value is:"+this.businessArea+","+  this.productconfiguration
      +","+this.workType);
     
    }
}