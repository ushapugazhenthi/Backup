import { Injectable } from '@angular/core';

@Injectable()
export class AccountInfoServiceComponent{
    headquarterCountry:string;
   geoScope:string;
    
    accounForm:AccountInfoFormData;
    
    accountFormData(headQuar:string, geosco:string){
       this.headquarterCountry=headQuar;
       this.geoScope =geosco;
       console.log("the Policy info Data received in the service is: "+this.headquarterCountry +", "+
        this.geoScope )
    }
    
    getTheAccountData(){
        this.accounForm ={
           hqc: this.headquarterCountry,
           gs:this.geoScope
          
        }
        
        console.log("The Value returned to  the  Policycomponent is:"+ this.accounForm.hqc+","
        + this.accounForm.gs  );
       
         
       
       // return this.pc;
       return this.accounForm;
    }
    
}

export class AccountInfoFormData {
 hqc: string;
  gs: string;
  
}