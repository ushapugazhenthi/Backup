import { Injectable } from '@angular/core';

@Injectable()
export class ClientInfoServiceComponent{
   ph:string;
   ia:string;
    
    clientForm:ClientInfoFormData;
    
    clientFormData(policyHolder:string, insuredAddress:string){
       this.ph=policyHolder;
       this.ia =insuredAddress;
       console.log("the Client info Data received in the service is: "+this.ph +", "+ this.ia )
    }
    
    getTheClientsData():ClientInfoFormData{
        this.clientForm ={
           policyholder: this.ph,
           insuredAddress:this.ia
          
        }
        
        console.log("The Value returned to  the  clientcomponent is:"+ this.clientForm.policyholder+","
        + this.clientForm.insuredAddress);
       
         
       
       // return this.pc;
       return this.clientForm;
    }
    
}

export class ClientInfoFormData {
 policyholder: string;
  insuredAddress: string;
  
}