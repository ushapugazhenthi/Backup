import { Injectable } from '@angular/core';

@Injectable()
export class BasicInfoSectionService{
    pc:string;
    ba:string;
    wt:string;
    
    
    
    basicFormData(productconfiguration:string, businessA:string,
    workType:string){
        this.pc=productconfiguration;
        this.ba= businessA;
        this.wt=workType;
        console.log("The Value from the compo is :"+ 
         this.pc+", "+this.ba+","+this.wt);
    }
    
    getTheData():BasicInfoFormData{
        console.log("Hello Service");
        console.log("The Value returned to  the component is:"+ 
         this.pc);
         this.basicInfo ={
             proConfig:this.pc,
             businessArea:this.ba,
             workType:this.wt
       
         }
         console.log("Model Data is:" +this.basicInfo.proConfig)
       // return this.pc;
       return this.basicInfo;
    }
    
}

export class BasicInfoFormData {
  proConfig: string;
  businessArea: string;
  workType:string;
}