import { Component } from '@angular/core';
import {Router} from '@angular/router';
import{PolicyInfoServiceComponent} from './policyinfo.service';
import{PolicyInfoFormData} from './policyinfo.service';

@Component({
    selector :'policy-information',
    templateUrl :'./policy.html'
    
    
})

export class PolicyComponent
{
     treatyType:string;
    marketPosition:string;
    policyInfo:PolicyInfoFormData;
    
     ngOnInit() : void
    {
       
        
        this.policyInfo=this.policyService.getThePolicyData();
        this.treatyType=this.policyInfo.treatyType;
        this. marketPosition=this.policyInfo.marketPosition;
        
        console.log("The Policy Form Model value from the  service is: "
       + this.policyInfo.treatyType+
        "," +this.policyInfo.marketPosition);
    }
   
    

    
    goToClientInfo(){
       this.router.navigateByUrl('/pages/submissionInfo/clientinformations'); 
    }
    
    goToAccountInfo(){
      this.router.navigateByUrl('/pages/submissionInfo/accountinfo');  
    }
    onSubmit(formPolicyInfoValue){
        
        this.treatyType =formPolicyInfoValue.treatyType;
      this.marketPosition=formPolicyInfoValue.marketPosition;
       console.log("The Policy Form value is:"+this.treatyType+","+ 
        this.marketPosition);
      this.policyService.policyFormData(this.treatyType,this.marketPosition)
        
    }
    constructor(private router:Router,
    private policyService:PolicyInfoServiceComponent){}
}