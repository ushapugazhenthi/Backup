import { Component } from '@angular/core';
import {Router} from '@angular/router';


@Component({
    selector :'h1',
    templateUrl :'<h2> hello Usha P</h2>',
   
    
    
})
export class PaginateTableComponent{}
