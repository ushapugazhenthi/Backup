import { Component } from '@angular/core';
import {Router} from '@angular/router';
import{ClientInfoServiceComponent} from './clientinfo.service.component';
import {ClientInfoFormData} from './clientinfo.service.component';

@Component({
    selector :'client-information',
    templateUrl:'./clientinfo.html'
   
})

export class ClientInfoComponent implements OnInit{
    
    policyholder:string;
    insuredAddress:string;
    clientInfo:ClientInfoFormData;
     ngOnInit() : void
    {
       
        
        this.clientInfo=this.clientService.getTheClientsData();
        this.policyholder=this.clientInfo.policyholder;
        this. insuredAddress=this.clientInfo.insuredAddress;
        
        console.log("The client Form Model value from the  service is: "
       + this.clientInfo.policyholder+
        "," +this.clientInfo.insuredAddress);
    }
   
   
    gotoBasicInfo(){
        console.log("Hello USha P");
        
        this.router.navigateByUrl('/pages/submissionInfo/basicinformations');
        
    }
    
    goToPolicy(){
        this.router.navigateByUrl('/pages/submissionInfo/policyinfo');
    }
    constructor(private router:Router,
    private clientService:ClientInfoServiceComponent){}
    
    onSubmit(formClientInfo){ 
      this.policyholder =formClientInfo.policyholder;
      this.insuredAddress=formClientInfo.insuredAddress;
       console.log("The client Form value is:"+this.policyholder+","+ 
        this.insuredAddress);
      this.clientService.clientFormData(this.policyholder,this.insuredAddress)
 
    }
   
    
    
}