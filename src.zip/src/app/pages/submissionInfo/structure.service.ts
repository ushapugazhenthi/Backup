import { Injectable } from '@angular/core';

@Injectable()
export class StructureInfoServiceComponent{
    currency:string;
   brokertargetprices:string;
    
    structureForm:StructureInfoFormData;
    
    structureFormData(currency:string, brokertp:string){
       this.currency=currency;
       this.brokertargetprices =brokertp;
       this.currency=currency;
       console.log("the Policy info Data received in the service is: "+this.currency +", "+
        this.brokertargetprices )
    }
    
    getTheStructurData(){
        this.structureForm ={
           currency: this.currency,
            btp :this.brokertargetprices
          
        }
        
        console.log("The Value returned to  the  Policycomponent is:"+ this.structureForm.currency+","
        + this.structureForm.btp  );
       
         
       
       // return this.pc;
       return this.structureForm;
    }
    
}

export class StructureInfoFormData {
 currency: string;
  btp: string;
  
}