import {Component} from '@angular/core';


@Component({
  selector: 'submissiondetail-test',
  templateUrl: './dashboard.component.html',
})
export class SubmissionDetailComponent {

}