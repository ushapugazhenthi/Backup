import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {SubmissionInfoComponent} from './submissioninfo.component';
import {BasicInfoSectionDetailsComponent} from './basicinfosectiondetails.component';
import {ClientInfoComponent} from './clientinfo.component';
import { routing } from './submissioninfo.routing.module';
import { MaterialModule } from '@angular/material';
import { NgaModule } from '../../theme/nga.module';
import {PolicyComponent} from './policy.component';
import {AccountInformationComponent}  from './accountinfo.component';
import {StructureComponent} from './structure.component';
import {HistoricalComponent} from './historical.component';
import {BasicInfoSectionService} from './basicinfosection.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    routing,
    MaterialModule.forRoot()
  ],
  declarations: [
    SubmissionInfoComponent,
    BasicInfoSectionDetailsComponent,
    ClientInfoComponent,
    PolicyComponent,
    AccountInformationComponent,
    StructureComponent,
    HistoricalComponent
    
  ],
  
  // /providers: [ HeroService ],
})
export class SubmissionInfoModule {
  
  
//  / constructor(private basicInfoSectionService:BasicInfoSectionService){}
}