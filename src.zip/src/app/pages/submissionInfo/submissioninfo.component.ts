import {Component} from '@angular/core';

@Component({
  selector: 'submission-test',
    templateUrl:'./dashboard/submissioninfo.component.html'
    
    
})
export class SubmissionInfoComponent {
  constructor() {}
}