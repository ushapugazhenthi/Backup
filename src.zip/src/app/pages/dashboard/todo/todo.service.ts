import {Injectable} from '@angular/core';

@Injectable()
export class TodoService {

  private _todoList = [
    { text: 'TODO 1' },
    { text: 'TODO 2' },
     { text: 'TODO 3' },
      { text: 'TODO 4' },
       { text: 'TODO 5' },
        { text: 'TODO 6' },
         { text: 'TODO 7' },
          { text: 'TODO 8' },
          
  ];

  getTodoList() {
    return this._todoList;
  }
}
