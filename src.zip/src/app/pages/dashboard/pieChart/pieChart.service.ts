import {Injectable} from '@angular/core';
import {BaThemeConfigProvider, colorHelper} from '../../../theme';

@Injectable()
export class PieChartService {

  constructor(private _baConfig:BaThemeConfigProvider) {
  }

  getData() {
    let pieColor = this._baConfig.get().colors.custom.dashboardPieChart;
    return [
      {
        color: pieColor,
        description: 'My Deals',
        background:'Purple',
        stats: '100',
        icon: 'person',
      }, {
        color: pieColor,
        description: 'My Pending Deals',
        background:'Indigo',
        stats: '200',
        icon: 'document',
      }, {
        color: pieColor,
        description: 'My Team Deals',
          background:'Blue',
        stats: '500',
        icon: 'document',
      },
      
       {
        color: pieColor,
        description: 'Recently Viewed Deals',
        background:'DeepOrange',
        stats: '50',
        icon: 'document',
      }
      //,{
      //  color: pieColor,
      //  description: 'My Assigned Tasks',
      //    background:'LightBlue',
      //  stats: '500',
      //  icon: 'document',
      //},
      //{
      //  color: pieColor,
      //  description: 'My Requested Tasks',
      //    background:'Cyan',
      //  stats: '500',
      //  icon: 'document',
      //},
      //{
      //  color: pieColor,
      //  description: 'My Reminder/Dairies',
      //    background:'Green',
      //  stats: '500',
      //  icon: 'document',
      //},
      // {
      //  color: pieColor,
      //  description: 'My Tasks overdue/due soon',
      //    background:'Teal ',
      //  stats: '500',
      //  icon: 'document',
      //}
      
    ];
  }
}
