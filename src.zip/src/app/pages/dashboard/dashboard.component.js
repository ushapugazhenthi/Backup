"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var highcharts_3d_1 = require('highcharts/highcharts-3d');
var highcharts_more_1 = require('highcharts/highcharts-more');
require('highcharts/modules/solid-gauge');
var Highcharts = require('highcharts/highcharts');
highcharts_3d_1.default(Highcharts);
highcharts_more_1.default(Highcharts);
var Dashboard = (function () {
    function Dashboard() {
        this.load();
    }
    Dashboard.prototype.getActivityType = function () {
        return 'ACTIVITY';
    };
    Dashboard.prototype.getClaimType = function () {
        return 'CLAIMS';
    };
    Dashboard.prototype.load = function () {
        this.userWorkLoadOptions = {
            chart: {
                type: 'areaspline',
                backgroundColor: 'transparent',
                height: 300
            },
            title: {
                text: ''
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                verticalAlign: 'top',
                x: 80,
                y: 0,
                floating: true,
                borderWidth: 1
            },
            xAxis: {
                categories: [
                    'Monday',
                    'Tuesday',
                    'Wednesday',
                    'Thursday',
                    'Friday',
                    'Saturday',
                    'Sunday'
                ]
            },
            yAxis: {
                title: {
                    text: 'Activity Count'
                }
            },
            tooltip: {
                shared: true,
                valueSuffix: ' units'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                series: {
                    fillColor: {
                        linearGradient: [0, 0, 0, 300],
                        stops: [
                            [0, '#2196f3'],
                            [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                        ]
                    }
                }
            },
            series: [{
                    name: 'My Assigned Activities',
                    color: '#673ab7',
                    data: [10, 500, 200, 600, 100, 400, 50]
                }, {
                    name: 'New Activities',
                    color: '#4caf50',
                    data: [10, 800, 100, 700, 200, 700, 150]
                }]
        };
        this.fnol = {
            chart: {
                type: 'pie',
                backgroundColor: 'transparent',
                width: 300,
                height: 150,
                options3d: {
                    enabled: true,
                    alpha: 45
                },
                margin: [10, 0, 0, 0],
                spacingTop: 0,
                spacingBottom: 0,
                spacingLeft: 0,
                spacingRight: 0
            },
            title: {
                text: 'FNOL'
            },
            plotOptions: {
                pie: {
                    innerSize: 60,
                    depth: 15,
                    colors: ['#f44336', '#ffc107', '#4caf50'],
                    dataLabels: {
                        enabled: false
                    }
                }
            },
            series: [{
                    name: 'Count',
                    data: [
                        ['Red', 8],
                        ['Orrange', 3],
                        ['Green', 1]
                    ]
                }]
        };
        this.financial = {
            chart: {
                type: 'pie',
                backgroundColor: 'transparent',
                width: 300,
                height: 150,
                options3d: {
                    enabled: true,
                    alpha: 45
                },
                margin: [10, 0, 0, 0],
                spacingTop: 0,
                spacingBottom: 0,
                spacingLeft: 0,
                spacingRight: 0
            },
            title: {
                text: 'Financial'
            },
            plotOptions: {
                pie: {
                    innerSize: 60,
                    depth: 15,
                    colors: ['#f44336', '#ffc107', '#4caf50'],
                    dataLabels: {
                        enabled: false
                    }
                }
            },
            series: [{
                    name: 'Count',
                    data: [
                        ['Red', 25],
                        ['Orrange', 33],
                        ['Green', 51]
                    ]
                }]
        };
        this.statusUpdate = {
            chart: {
                type: 'pie',
                backgroundColor: 'transparent',
                width: 300,
                height: 150,
                options3d: {
                    enabled: true,
                    alpha: 45
                },
                margin: [10, 0, 0, 0],
                spacingTop: 0,
                spacingBottom: 0,
                spacingLeft: 0,
                spacingRight: 0
            },
            title: {
                text: 'Status Update'
            },
            plotOptions: {
                pie: {
                    innerSize: 60,
                    depth: 15,
                    colors: ['#f44336', '#ffc107', '#4caf50'],
                    dataLabels: {
                        enabled: false
                    }
                }
            },
            series: [{
                    name: 'Count',
                    data: [
                        ['Red', 6],
                        ['Orrange', 13],
                        ['Green', 16]
                    ]
                }]
        };
        this.suspended = {
            chart: {
                type: 'pie',
                background: null,
                backgroundColor: 'transparent',
                width: 300,
                height: 150,
                options3d: {
                    enabled: true,
                    alpha: 45
                },
                margin: [10, 0, 0, 0],
                spacingTop: 0,
                spacingBottom: 0,
                spacingLeft: 0,
                spacingRight: 0
            },
            title: {
                text: 'Suspended'
            },
            plotOptions: {
                pie: {
                    innerSize: 60,
                    depth: 15,
                    colors: ['#f44336', '#ffc107', '#4caf50'],
                    dataLabels: {
                        enabled: false
                    }
                }
            },
            series: [{
                    name: 'Count',
                    data: [
                        ['Red', 18],
                        ['Orrange', 3],
                        ['Green', 10]
                    ]
                }]
        };
        this.marketPosChart = {
            chart: {
                type: 'bar',
                backgroundColor: 'transparent',
                width: 600,
                height: 300,
            },
            title: {
                text: ''
            },
            xAxis: {
                categories: ['FNOL', 'Financial', 'Suspended', 'Others', 'Collaborations']
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Total pending Count'
                }
            },
            legend: {
                reversed: true
            },
            plotOptions: {
                series: {
                    stacking: 'normal'
                },
            },
            series: [{
                    name: 'Leader',
                    color: '#f44336',
                    data: [5, 3, 4, 7, 2]
                }, {
                    name: 'Follower',
                    color: '#4caf50',
                    data: [2, 2, 3, 2, 1]
                }]
        };
        // The speed gauge
    };
    Dashboard = __decorate([
        core_1.Component({
            selector: 'dashboard',
            styleUrls: ['./dashboard.scss'],
            templateUrl: './dashboard.html'
        })
    ], Dashboard);
    return Dashboard;
}());
exports.Dashboard = Dashboard;
