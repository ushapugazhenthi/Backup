import {Component} from '@angular/core';
import 'style-loader!./popularApp.scss';

@Component({
  selector: 'popular-app',
  templateUrl: './popularApp.html'
})
export class PopularApp {

  ngOnInit() {
  }
}
