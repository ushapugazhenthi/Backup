import {Injectable} from '@angular/core';

@Injectable()
export class FeedService {

  private _data = [
    {
    }
  ];

  getData() {
    return this._data;
  }
}
