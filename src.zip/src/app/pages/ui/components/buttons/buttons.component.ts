import {Component} from '@angular/core';

import 'style-loader!./buttons.scss';

@Component({
  selector: 'buttons',
  templateUrl: './buttons.html',
})
export class Buttons {

  constructor() {
  }
}
