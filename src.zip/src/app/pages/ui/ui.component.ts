import {Component} from '@angular/core';

@Component({
  selector: 'ui',
  template: `<router-outlet></router-outlet>`
})
export class Ui {

  constructor() {
  }
}
