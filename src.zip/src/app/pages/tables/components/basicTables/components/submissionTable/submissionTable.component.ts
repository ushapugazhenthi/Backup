import {Component} from '@angular/core';

import {BasicTablesService} from '../../basicTables.service';

@Component({
  selector: 'submission-table',
  templateUrl: './submissionTable.html'
})
export class SubmissionTable {

 
  
  smartTableSubmissionData:Array<any>;

  constructor(private _basicTablesService: BasicTablesService) {
  this.smartTableSubmissionData=_basicTablesService.smartTableSubmissionData;
  }
}