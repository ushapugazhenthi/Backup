export * from './charts.component';
