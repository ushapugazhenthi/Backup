import { Routes, RouterModule }  from '@angular/router';
import { ClaimSummaryComponent } from './claimSummary.component';
import {BasicInformationComponent} from './BasicInformation.component';
const routes: Routes = [
 
  {
    path: '',
    component: ClaimSummaryComponent
  },
  
  /*
   {
    path: '',
    component: BasicInformationComponent
  }
  */
];

export const routing = RouterModule.forChild(routes);