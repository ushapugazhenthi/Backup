import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { ClaimSummaryComponent } from './claimSummary.component';
import { ClaimSummaryDashboardComponent } from './dashboard/dashboard.component';
import { routing } from './claimSummary.routing';
import { MaterialModule } from '@angular/material';
import { NgaModule } from '../../theme/nga.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    routing,
    MaterialModule.forRoot()
  ],
  declarations: [
    ClaimSummaryComponent,ClaimSummaryDashboardComponent
  ]
})
export class ClaimSummaryModule {}