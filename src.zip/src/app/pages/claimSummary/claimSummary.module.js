"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var claimSummary_component_1 = require('./claimSummary.component');
var dashboard_component_1 = require('./dashboard/dashboard.component');
var claimSummary_routing_1 = require('./claimSummary.routing');
var material_1 = require('@angular/material');
var nga_module_1 = require('../../theme/nga.module');
var ClaimSummaryModule = (function () {
    function ClaimSummaryModule() {
    }
    ClaimSummaryModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                nga_module_1.NgaModule,
                claimSummary_routing_1.routing,
                material_1.MaterialModule.forRoot()
            ],
            declarations: [
                claimSummary_component_1.ClaimSummaryComponent, dashboard_component_1.ClaimSummaryDashboardComponent
            ]
        })
    ], ClaimSummaryModule);
    return ClaimSummaryModule;
}());
exports.ClaimSummaryModule = ClaimSummaryModule;
