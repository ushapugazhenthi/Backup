import {Component} from '@angular/core';
declare var require: any;
var Highcharts = require('highcharts/highcharts');

@Component({
  selector: 'claim-summary-dashboard',
  templateUrl: './dashboard.component.html',
})
export class ClaimSummaryDashboardComponent {
private   bookingChartOptions: Object;
private   coInsuranceOptions: Object;

 constructor() {
       this.load();
       //debugger;
    }
  
getMailsType(): String {

        return 'MAILS';
}

load():void {
  this.loadCoInsurance();
  //debugger;
   this. loadBookingSummary();
}

loadCoInsurance() {

   //  debugger;
  this. coInsuranceOptions = {   
      chart: {
        height: 300
        
      
    },
     title: {
        text: 'Coinsurance',
        align: 'center',
        verticalAlign: 'middle',
        y: 10
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}</b>'
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: true,
                distance: -20,
                style: {
                    fontWeight: 'bold',
                    color: 'white'
                }
            },
            startAngle: 0,
            endAngle: 360,
            center: ['50%', '50%']
        }
    },
    series: [{
        type: 'pie',
         shadow: true,
        name: 'Coinsurance share',
        innerSize: '50%',
        data: [
            ['SwissRe',   40],
            ['AXA',       20],
            ['Alianz', 15],
            ['MMA',    12],
            ['Zurich',    13],
           
        ]
   
 }]
  }
   

     
}

loadBookingSummary() {

      this.bookingChartOptions = {
chart: {
        type: 'bar',
        spacingBottom: 15,
        spacingTop: 10,
        spacingLeft: 10,
        spacingRight: 10,

        // Explicitly tell the width and height of a chart
        
        height: 300,
        
        
    },
    style: {
           
        }
,
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: ['Booking Summary'],
        title: {
            text: null
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: '',
            align: 'high'
        },
        labels: {
            overflow: 'justify'
        }
    },
    tooltip: {
        valueSuffix: ''
    },
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: true
            }
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 80,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    },
    credits: {
        enabled: false
    },
    series: [{
        name: 'Free Payments',
        data: [1700]
    }, {
        name: 'Free Reserve',
        data: [2800]
    }, {
        name: 'Indemnity Payments',
        data: [9000]
    },
    {
        name: 'Indemnity Reserves',
        data: [1500]
    }
    ]
      };
    }
   



  
}