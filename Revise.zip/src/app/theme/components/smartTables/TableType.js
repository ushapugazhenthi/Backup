"use strict";
(function (TableType) {
    TableType[TableType["CLAIM"] = 0] = "CLAIM";
    TableType[TableType["ACTIVITY"] = 1] = "ACTIVITY";
    TableType[TableType["COLLABORATION"] = 2] = "COLLABORATION";
})(exports.TableType || (exports.TableType = {}));
var TableType = exports.TableType;
