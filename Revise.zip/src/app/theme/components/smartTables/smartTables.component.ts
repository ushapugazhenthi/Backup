import { Component,Input } from '@angular/core';

import { SmartTablesService } from '../../services/smartTable/smartTables.service';
import { LocalDataSource } from 'ng2-smart-table';


import 'style-loader!./smartTables.scss';

@Component({
  selector: 'smart-tables',
  templateUrl: './smartTables.html',
})
export class SmartTables {

  query: string = '';
@Input() tableTypeString:string;

 activitySettings = {
    add: {
      addButtonContent: '<i class="ion-ios-plus-outline"></i>',
      createButtonContent: '<i class="ion-checkmark"></i>',
      cancelButtonContent: '<i class="ion-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="ion-edit"></i>',
      saveButtonContent: '<i class="ion-checkmark"></i>',
      cancelButtonContent: '<i class="ion-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="ion-trash-a"></i>',
      confirmDelete: true
    },
    columns: {
      id: {
        title: 'ID',
        type: 'number'
      },
      firstName: {
        title: 'First Name',
        type: 'string'
      },
      lastName: {
        title: 'Last Name',
        type: 'string'
      },
      username: {
        title: 'Username',
        type: 'string'
      },
      email: {
        title: 'E-mail',
        type: 'string'
      },
      age: {
        title: 'Age',
        type: 'number'
      }
    }
  };
  
  
 claimsSettings = {
 
    add: {
      addButtonContent: '<i class="ion-ios-plus-outline"></i>',
      createButtonContent: '<i class="ion-checkmark"></i>',
      cancelButtonContent: '<i class="ion-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="ion-edit"></i>',
      saveButtonContent: '<i class="ion-checkmark"></i>',
      cancelButtonContent: '<i class="ion-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="ion-trash-a"></i>',
      confirmDelete: true
    },
    columns: {
      id: {
        title: 'Claim Number',
        type: 'number'
      },
      firstName: {
        title: 'Policy Number',
        type: 'string'
      },
      lastName: {
        title: 'Status',
        type: 'string'
      },
      username: {
        title: 'Main LOB',
        type: 'string'
      },
      email: {
        title: 'Claimant',
        type: 'string'
      },
      age: {
        title: 'Age',
        type: 'number'
      }
    }
  };
  

 mailsSettings = {

     add: {
         addButtonContent: '<i class="ion-ios-plus-outline"></i>',
         createButtonContent: '<i class="ion-checkmark"></i>',
         cancelButtonContent: '<i class="ion-close"></i>',
     },
     edit: {
         editButtonContent: '<i class="ion-edit"></i>',
         saveButtonContent: '<i class="ion-checkmark"></i>',
         cancelButtonContent: '<i class="ion-close"></i>',
     },
     delete: {
         deleteButtonContent: '<i class="ion-trash-a"></i>',
         confirmDelete: true
     },
     columns: {
         id: {
             title: 'Loked By',
             type: 'number'
         },
         firstName: {
             title: 'Recevied Date',
             type: 'string'
         },
         lastName: {
             title: 'Line Of Business',
             type: 'string'
         },
         username: {
             title: 'Subject',
             type: 'string'
         },
         email: {
             title: 'Sent By',
             type: 'string'
         },
         age: {
             title: 'Submission Handled By',
             type: 'number'
         }
     }
 };


  source: LocalDataSource = new LocalDataSource();

  constructor(protected service: SmartTablesService) {
    this.service.getData().then((data) => {
      this.source.load(data);
    });
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }
}
