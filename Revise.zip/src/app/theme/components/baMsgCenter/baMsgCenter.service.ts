import {Injectable} from '@angular/core'

@Injectable()
export class BaMsgCenterService {

  private _notifications = [
    {
      name: 'S3KSZM',
      text: 'First Notification.',
      time: '1 min ago'
    },
    {
      name: 'S3KSZM',
      text: 'Second Notification.',
      time: '2 hrs ago'
    },
    {
      name: 'S3KSZM',
      text: '3rd Notification.',
      time: '5 hrs ago'
    }
  ];

  private _messages = [
    {
      name: 'S3KSZM',
      text: 'Test Msg 1...',
      time: '1 min ago'
    },
    {
      name: 'S3KSZM',
      text: 'Test Message 2.',
      time: '2 hrs ago'
    },
    {
        name: 'S3KSZM',
      text: 'Test Message 3..',
      time: '10 hrs ago'
    },
    {
        name: 'S3KSZM',
      text: 'Test Message 4...',
      time: '1 day ago'
    }
   
  ];

  public getMessages():Array<Object> {
    return this._messages;
  }

  public getNotifications():Array<Object> {
    return this._notifications;
  }
}
