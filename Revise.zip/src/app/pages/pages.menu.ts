export const PAGES_MENU = [
    {
        path: 'pages',
        // parent route
        children: [
            {
                path: 'dashboard',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Dashboard',
                        icon: 'ion-android-desktop',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },
            {
                path: 'mails',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Mails',
                        icon: 'ion-email',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },

            {
                // parent route
                path: 'submissions',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Submissions',
                        icon: 'ion-document-text',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },

                // children routes
                children: [
                    {
                        path: 'new',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'New Submission',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        },
                        
                        //ms sections
                     
                     
                  children: [
                      
                    {          
                    path: 'basic',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Basic Info',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                    
                    {          
                    path: 'client',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Client info',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                    {          
                    path: 'policy',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Policy',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                    {          
                    path: 'account',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Account Info',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                    
                    {          
                    path: 'structure',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Structure',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                    {          
                    path: 'historical',
                       data: {

                            // children menu item configuration
                            menu: {
                                title: 'Historical Info',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 1,
                                }
                                }
                    },
                    
                  ]
                     }

                   ,
                      //ms 
                        
                    
                    
                    
                    {
                        path: 'existing',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'Existing',
                                icon: 'ion-document-text',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        }
                    }
                ]
            },
            {
                // parent route
                path: 'deals',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Deals',
                        icon: 'ion-compose',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },

                // children routes
                children: [
                    {
                        path: 'new',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'New',
                                icon: 'ion-compose',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        }
                    },
                    {
                        path: 'existing',
                        data: {

                            // children menu item configuration
                            menu: {
                                title: 'Existing',
                                icon: 'ion-compose',
                                selected: false,
                                expanded: false,
                                order: 0,
                            }
                        }
                    }
                ]
            },
            {
                path: 'tasks',
                data: {

                    // parent menu configuration
                    menu: {
                        title: 'Tasks',
                        icon: 'ion-clipboard',
                        selected: false,
                        expanded: false,
                        order: 0,
                    }
                },
            },
        ]

    }

];
