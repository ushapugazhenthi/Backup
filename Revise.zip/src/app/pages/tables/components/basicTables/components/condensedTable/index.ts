export * from './condensedTable.component';
