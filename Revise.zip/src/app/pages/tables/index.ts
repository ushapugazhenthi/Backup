export * from './tables.component';
