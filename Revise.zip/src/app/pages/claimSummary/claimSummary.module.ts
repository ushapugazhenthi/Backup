import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { ClaimSummaryComponent } from './claimSummary.component';
import { ClaimSummaryDashboardComponent } from './dashboard/dashboard.component';
import { routing } from './claimSummary.routing';
import { MaterialModule } from '@angular/material';
import { NgaModule } from '../../theme/nga.module';

@NgModule({
  imports: [
    CommonModule,
    NgaModule,
    routing,
    MaterialModule.forRoot()
  ],
  declarations: [
    ClaimSummaryComponent,ClaimSummaryDashboardComponent
  ]
})
export class ClaimSummaryModule {}