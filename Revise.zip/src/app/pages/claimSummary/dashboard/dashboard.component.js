"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var Highcharts = require('highcharts/highcharts');
var ClaimSummaryDashboardComponent = (function () {
    function ClaimSummaryDashboardComponent() {
        this.load();
    }
    ClaimSummaryDashboardComponent.prototype.load = function () {
        this.loadCoInsurance();
        this.loadBookingSummary();
    };
    ClaimSummaryDashboardComponent.prototype.loadCoInsurance = function () {
        this.coInsuranceOptions = {
            chart: {
                height: 300
            },
            title: {
                text: 'Coinsurance',
                align: 'center',
                verticalAlign: 'middle',
                y: 10
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.percentage:.1f}</b>'
            },
            plotOptions: {
                pie: {
                    dataLabels: {
                        enabled: true,
                        distance: -20,
                        style: {
                            fontWeight: 'bold',
                            color: 'white'
                        }
                    },
                    startAngle: 0,
                    endAngle: 360,
                    center: ['50%', '50%']
                }
            },
            series: [{
                    type: 'pie',
                    shadow: true,
                    name: 'Coinsurance share',
                    innerSize: '50%',
                    data: [
                        ['SwissRe', 40],
                        ['AXA', 20],
                        ['Alianz', 15],
                        ['MMA', 12],
                        ['Zurich', 13],
                    ]
                }]
        };
    };
    ClaimSummaryDashboardComponent.prototype.loadBookingSummary = function () {
        this.bookingChartOptions = {
            chart: {
                type: 'bar',
                spacingBottom: 15,
                spacingTop: 10,
                spacingLeft: 10,
                spacingRight: 10,
                // Explicitly tell the width and height of a chart
                height: 300,
            },
            style: {},
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: ['Booking Summary'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: '',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -40,
                y: 80,
                floating: true,
                borderWidth: 1,
                backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
                shadow: true
            },
            credits: {
                enabled: false
            },
            series: [{
                    name: 'Free Payments',
                    data: [1700]
                }, {
                    name: 'Free Reserve',
                    data: [2800]
                }, {
                    name: 'Indemnity Payments',
                    data: [9000]
                },
                {
                    name: 'Indemnity Reserves',
                    data: [1500]
                }
            ]
        };
    };
    ClaimSummaryDashboardComponent = __decorate([
        core_1.Component({
            selector: 'claim-summary-dashboard',
            templateUrl: './dashboard.component.html',
        })
    ], ClaimSummaryDashboardComponent);
    return ClaimSummaryDashboardComponent;
}());
exports.ClaimSummaryDashboardComponent = ClaimSummaryDashboardComponent;
