"use strict";
var router_1 = require('@angular/router');
var claimSummary_component_1 = require('./claimSummary.component');
var routes = [
    {
        path: '',
        component: claimSummary_component_1.ClaimSummaryComponent
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
