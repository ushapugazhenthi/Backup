import { Routes, RouterModule }  from '@angular/router';
import { ClaimSummaryComponent } from './claimSummary.component';

const routes: Routes = [
  {
    path: '',
    component: ClaimSummaryComponent
  }
];

export const routing = RouterModule.forChild(routes);