"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var PieChartService = (function () {
    function PieChartService(_baConfig) {
        this._baConfig = _baConfig;
    }
    PieChartService.prototype.getData = function () {
        var pieColor = this._baConfig.get().colors.custom.dashboardPieChart;
        return [
            {
                color: pieColor,
                description: 'New Activities',
                background: 'Purple',
                stats: '100',
                icon: 'person',
            }, {
                color: pieColor,
                description: 'My Assigned Activites',
                background: 'Indigo',
                stats: '200',
                icon: 'document',
            }, {
                color: pieColor,
                description: 'All Activities',
                background: 'Blue',
                stats: '500',
                icon: 'document',
            },
            {
                color: pieColor,
                description: 'Suspended Activies',
                background: 'Teal',
                stats: '500',
                icon: 'document',
            },
            {
                color: pieColor,
                description: 'My Assigned Tasks',
                background: 'LightBlue',
                stats: '500',
                icon: 'document',
            },
            {
                color: pieColor,
                description: 'My Requested Tasks',
                background: 'Cyan',
                stats: '500',
                icon: 'document',
            },
            {
                color: pieColor,
                description: 'My Reminder/Dairies',
                background: 'Green',
                stats: '500',
                icon: 'document',
            },
            {
                color: pieColor,
                description: 'My Tasks overdue/due soon',
                background: 'DeepOrange ',
                stats: '500',
                icon: 'document',
            }
        ];
    };
    PieChartService = __decorate([
        core_1.Injectable()
    ], PieChartService);
    return PieChartService;
}());
exports.PieChartService = PieChartService;
