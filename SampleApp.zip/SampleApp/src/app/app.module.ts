/*
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
*/
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MaterialModule, MdNativeDateModule} from '@angular/material';

import {HttpModule} from '@angular/http';
import { RouterModule }   from '@angular/router';
import {DashboardComponent} from './dashboard.component';
import 'hammerjs';

import {AppComponent} from './app.component';
 
import {AgGridModule} from "ag-grid-angular/main";
import {GridComponent} from './grid.component';
@NgModule({

  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    MaterialModule,
    MdNativeDateModule,
    ReactiveFormsModule,
    
    AgGridModule.withComponents(
    []
),

    RouterModule.forRoot(
      [
        {
          path:'dashboard',
          component:DashboardComponent
        }
      ]
    )
  ],

  declarations: [ AppComponent,DashboardComponent, 
   GridComponent],
  bootstrap: [AppComponent],
  providers: []
})
export class AppModule { }